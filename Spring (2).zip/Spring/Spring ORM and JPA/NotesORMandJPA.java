public class NotesORMandJPA {
    public static void main(String[] args) {
        System.out.println("NotesORM initialized.");
    }
    // Since ORM without JPA requires you to manually configure the SessionFactory bean as Spring Boot does not auto-configure it, we will use Hibernate ORM with JPA in our demo project to take advantage of Spring Boot's auto-configuration features and simplify our setup.
    // Spring Boot's auto-configuration will automatically set up EntityManager and related beans based on the presence of JPA and Hibernate dependencies, allowing us to focus on our application logic rather than boilerplate configuration.
}

// SPRING ORM and JPA //

// Spring ORM is a module of the Spring Framework that provides integration with Object-Relational Mapping (ORM) frameworks such as Hibernate, JPA, and JDO.
// It simplifies the data access layer by providing a consistent way to interact with different ORM technologies, allowing developers to focus on business logic rather than boilerplate code for database operations.
// So it connects our spring application with ORM framework like hibernate.
// Features of Spring ORM:
// 1. Simplified Data Access: Spring ORM provides a consistent and simplified way to access data using ORM frameworks, reducing boilerplate code.
// 2. Transaction Management: It integrates with Spring's transaction management, allowing for declarative transaction handling.
// 3. Support for Multiple ORM Frameworks: Spring ORM supports various ORM frameworks, including Hibernate, JPA, and JDO.
// 4. Integration with Spring's Core Features: It seamlessly integrates with other Spring features like Dependency Injection and AOP.
// 5. Exception Translation: Spring ORM translates ORM-specific exceptions into Spring's DataAccessException hierarchy, making it easier to handle exceptions consistently.
// 6. Template Classes: It provides template classes (like HibernateTemplate) that simplify common data access operations. This was more prominent in older versions of Spring but is less emphasized in modern applications using Spring Data JPA.
// 7. Support for Lazy Loading and Caching: Spring ORM supports lazy loading and caching mechanisms provided by the underlying ORM frameworks.
// Overall, Spring ORM enhances the development experience when working with ORM frameworks in Spring applications, promoting best practices and reducing complexity in data access layers.

// Spring ORM takes care of instance creation.
// Configuration will be done in Spring configuration file (XML or Java-based).
// Transaction management will be handled by Spring Tx module.

// We will use the same demo project we previously created for Spring MVC.
// First, we will add the necessary dependencies - Hibernate ORM Hibernate Core, Spring Object/Relational Mapping, Spring Transaction, MySQL connector/J, C3P0 (for connection pooling).
// The listed dependencies are legacy and in modern Spring Boot applications, we use spring-boot-starter-data-jpa (has Hibernate as default JPA provider, Spring ORM, Spring Transaction, HikariCP (connection pooling; faster than C3P0)) and mysql-connector-java.
// We will use h2 database (in-memory database; no need to install anything) for now instead of sql.
// Then specify the database connection properties in application.properties file.
// Unlike for plain hibernate, we don't nee to specify hibernate dialect property as Spring Boot will auto-detect it based on the database url.

// We will have create a form in index.jsp to add Alien to h2 database and a button to show all aliens from the database.
// We annotate the Alien class with @Entity and specify the primary key with @Id annotation.
// This will not affect its use in other parts of the application (like in Spring MVC) as it will still work as a normal POJO.
// We will create a package repository to hold all dao classes (data access layer).
// We will create AlienRepo class in repository package to handle database operations related to Alien entity.
// We will annotate the class with @Repository to indicate that it's a repository bean.

// We will use @Transactional annotation to manage transactions in the repository class. This will ensure that all database operations are executed within a transaction context, providing data integrity and consistency.
// This also allows us to avoid boilerplate code for transaction management, as Spring will automatically handle the transaction boundaries for us based on the presence of the @Transactional annotation.
// It also allows us to specify the transaction attributes (like readOnly, propagation, isolation) to fine-tune the transaction behavior according to our needs.
// This also helps us to commit or rollback transactions automatically based on the success or failure of the database operations, ensuring that our data remains consistent and reliable.
// We use it in methods that perform database operations (like save, findAll) to ensure that they are executed within a transaction context, providing data integrity and consistency.

// We use the EntityManager to perform database operations in the repository class. The EntityManager is a JPA interface that provides methods for interacting with the persistence context and performing CRUD operations on entities.
// We inject the EntityManager using the @PersistenceContext annotation, which tells Spring to provide an instance of EntityManager that is associated with the current transaction context.
// We use the EntityManager's merge method to save or update an entity in the database. The merge method will either insert a new record if the entity is new (does not have an id) or update an existing record if the entity already exists (has an id).
// We use the EntityManager's createQuery method to execute a JPQL query to retrieve all Alien entities from the database. The query "from Alien" is a JPQL query that selects all records from the Alien entity, and we specify the result type as Alien.class to get a list of Alien objects as the result.
// EntityManager methods:
// 1. persist(Object entity): This method is used to save a new entity to the database. It makes the entity instance managed and persistent.
// 2. merge(Object entity): This method is used to update an existing entity in the database. It copies the state of the given entity onto the persistent entity with the same identifier and returns the managed instance.
// 3. remove(Object entity): This method is used to delete an entity from the database. It removes the entity instance from the persistence context and deletes the corresponding record from the database.
// 4. find(Class<T> entityClass, Object primaryKey): This method is used to retrieve an entity from the database based on its primary key. It returns the entity instance if found, or null if not found.
// 5. createQuery(String qlString, Class<T> resultClass): This method is used to create a JPQL query. It takes a JPQL query string and the expected result type, and returns a TypedQuery object that can be used to execute the query and retrieve results.
// 6. findAll(Class<T> entityClass): This method is not a standard EntityManager method, but it can be implemented using createQuery to retrieve all instances of a given entity class from the database. It typically executes a JPQL query like "from EntityClass" to get all records of that entity type.
// 7. update(Object entity): This method is not a standard EntityManager method, but it can be implemented using merge to update an existing entity in the database. It typically takes an entity instance with an existing id and updates the corresponding record in the database with the new state of the entity.

// persist vs merge: persist is used to save a new entity, while merge is used to update an existing entity. persist will throw an exception if the entity already exists in the database, while merge will update the existing record if the entity has an id that matches an existing record. persist makes the entity instance managed and persistent, while merge returns a managed instance that may be different from the original entity instance.

// The @PersistenceContext annotation is a JPA annotation that is used to inject an EntityManager instance into a Spring-managed bean. It tells Spring to provide an instance of EntityManager that is associated with the current transaction context, allowing us to perform database operations within a transactional scope. The @PersistenceContext annotation can be used on a field or a setter method to indicate that the EntityManager should be injected by Spring, enabling us to interact with the persistence context and perform CRUD operations on entities in our repository classes.
// It aslo allows us to specify the persistence unit name if we have multiple persistence units defined in our application, ensuring that the correct EntityManager is injected for the specific persistence unit we want to use. This is done using the 'unitName' attribute of the @PersistenceContext annotation.

// We will use the repository class in our controller to save and retrieve Alien entities from the database. We will autowire the AlienRepo bean in our HomeController and use its methods to perform database operations related to Alien entities. This allows us to separate the concerns of data access and business logic, promoting a cleaner and more maintainable code structure in our Spring application.
// Code:
// @Repository
// public class AlienRepo {
//
//     @PersistenceContext
//     private EntityManager em;
//
//     @Transactional
//     public Alien save(Alien alien) {
//         return em.merge(alien);
//     }
//
//     @Transactional(readOnly = true)
//     public List<Alien> findAll() {
//         return em.createQuery("from Alien", Alien.class)
//                 .getResultList();
//     }
// }

// This is the rough way to use JPA.
// In reality we will be creating a Spring Data JPA repository interface that extends JpaRepository, which will provide us with built-in methods for common database operations (like save, findAll, findById, delete) without the need to manually implement them using EntityManager. This allows us to leverage the power of Spring Data JPA and focus on our business logic rather than boilerplate code for data access.
// Code for Spring Data JPA repository:
// package com.example.demo.repository;
//
// import com.example.demo.model.Alien;
// import org.springframework.data.jpa.repository.JpaRepository;
// import org.springframework.stereotype.Repository;
//
// @Repository
// public interface AlienRepo extends JpaRepository<Alien, Integer> { // Assuming Alien has an Integer primary key
//     // No need to implement any methods as JpaRepository provides built-in methods for common database operations.
// }

// Advantage of using JpaRepository:
// 1. It provides built-in methods for common database operations (like save, findAll, findById, delete) without the need to manually implement them using EntityManager.
// 2. It allows us to leverage the power of Spring Data JPA and focus on our business logic rather than boilerplate code for data access.
// 3. It supports pagination and sorting out of the box, making it easier to handle large datasets and improve performance.
// 4. It provides support for query methods, allowing us to define custom queries based on method names without needing to write JPQL or SQL queries manually.
// 5. It integrates seamlessly with Spring's transaction management, ensuring that database operations are executed within a transactional context for data integrity and consistency.
// 6. It promotes a cleaner and more maintainable code structure by abstracting away the complexities of data access and allowing us to focus on our business logic.

// Query DSL in JpaRepository allows us to define custom query methods based on method names without needing to write JPQL or SQL queries manually.
// For example, if we have a property called 'name' in our Alien entity, we can define a method like findByName(String name) in our repository interface, and Spring Data JPA will automatically generate the appropriate query behind the scenes to retrieve entities based on the value of the 'name' property.
// This allows us to perform custom queries based on entity properties in a more intuitive and convenient way, without needing to write complex queries manually.
// Other examples of query methods include findByPropertyNameOrderByAgeDesc(String propertyValue), findByAgeGreaterThan(int age), findByStatus(String status), etc., where the method name follows a specific naming convention (like findBy followed by the property name and optional criteria) that Spring Data JPA uses to generate the appropriate query behind the scenes. This makes it easier to perform custom queries based on entity properties without needing to write JPQL or SQL queries manually, improving developer productivity and code readability.
// It is primarily used for retrieving data based on specific criteria defined in the method name, allowing us to easily perform complex queries without needing to write JPQL or SQL queries manually. This is particularly useful for filtering and searching data based on various properties of the entity, making it easier to implement features like search functionality, filtering options, and dynamic queries in our application.

// JpaRepository built-in methods:
// 1. save(S entity): Saves a given entity and returns the saved instance.
// 2. findById(ID id): Retrieves an entity by its id and returns an Optional containing the entity if found, or an empty Optional if not found.
// 3. findAll(): Retrieves all entities of the type and returns them as a List.
// 4. deleteById(ID id): Deletes the entity with the given id.
// 5. delete(T entity): Deletes a given entity.
// 6. count(): Returns the number of entities available.
// 7. existsById(ID id): Returns true if an entity with the given id exists, false otherwise.
// 8. findAll(Sort sort): Retrieves all entities sorted according to the given Sort object. The Sort object allows you to specify the sorting criteria (like ascending or descending) and the properties to sort by.
// 9. findAll(Pageable pageable): Retrieves a page of entities according to the given Pageable object. The Pageable object allows you to specify pagination information (like page number and page size) and sorting criteria, enabling you to retrieve a subset of entities in a paginated manner.
// 10. saveAll(Iterable<S> entities): Saves all given entities and returns the saved instances as a List.
// 11. deleteAll(Iterable<? extends T> entities): Deletes all given entities.
// 12. update(T entity): This method is not a standard JpaRepository method, but it can be implemented using save to update an existing entity in the database. It typically takes an entity instance with an existing id and updates the corresponding record in the database with the new state of the entity.
// 13. findByPropertyName(String propertyValue): This is an example of a query method that can be defined in a JpaRepository interface. It allows you to retrieve entities based on the value of a specific property without needing to write a JPQL or SQL query manually. The method name follows a specific naming convention (findBy followed by the property name) that Spring Data JPA uses to generate the appropriate query behind the scenes.
// 14. findByName(String name): This is another example of a query method that can be defined in a JpaRepository interface. It allows you to retrieve entities based on the value of the 'name' property without needing to write a JPQL or SQL query manually. The method name follows the naming convention (findBy followed by the property name) that Spring Data JPA uses to generate the appropriate query behind the scenes, making it easier to perform custom queries based on entity properties.
// Overall, JpaRepository provides a powerful and convenient way to perform database operations in Spring applications, allowing developers to focus on business logic while leveraging the capabilities of Spring Data JPA for data access.

// We have another interface extending JpaRepository instead of directly implementing it in the repository class.
// This is because Spring Data JPA will automatically generate the implementation of the repository interface at runtime, allowing us to define custom query methods based on method names without needing to write JPQL or SQL queries manually.
// By extending JpaRepository, we can take advantage of the built-in methods for common database operations while also defining our own custom query methods as needed, providing a flexible and powerful way to interact with the database in our Spring application.
// This approach promotes a cleaner and more maintainable code structure by abstracting away the complexities of data access and allowing us to focus on our business logic.

// NOTE: If AlienRepo extends JpaRepository and we don't have any custom query methods, we can directly autowire the AlienRepo interface in our controller and use its built-in methods (like save, findAll) to perform database operations related to Alien entities without needing to create a separate implementation class. This is because Spring Data JPA will automatically generate the implementation of the AlienRepo interface at runtime, allowing us to use it directly in our controller for data access operations. This simplifies our code and reduces boilerplate, as we can leverage the power of Spring Data JPA's built-in functionality without needing to write additional code for repository implementation.

// For custom queries in AlienRepo, we can define the queries using the @Query annotation on the method in the repository interface.
// This allows us to write JPQL or native SQL queries directly in the repository interface, providing a convenient way to perform complex queries that may not be easily expressed using method name conventions.
// The @Query annotation can be used to specify the query string and the expected result type, allowing us to retrieve data based on specific criteria defined in the query.
// This is particularly useful for scenarios where we need to perform more complex queries that cannot be easily expressed using method name conventions, giving us greater flexibility in our data access layer while still leveraging the benefits of Spring Data JPA.
// example of using @Query annotation:
// @Repository
// public interface AlienRepo extends JpaRepository<Alien, Integer> {
//     @Query("SELECT a FROM Alien a WHERE a.name = :name")
//     List<Alien> findByName(@Param("name") String name);
// }

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------




