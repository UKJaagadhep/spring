package com.example.demo.repository;

import com.example.demo.model.Alien;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class AlienRepo {

    @PersistenceContext
    private EntityManager em;

    @Transactional
    public Alien save(Alien alien) {
        return em.merge(alien);
    }

    @Transactional(readOnly = true)
    public List<Alien> findAll() {
        return em.createQuery("from Alien", Alien.class)
                .getResultList();
    }
}
