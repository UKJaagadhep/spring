package com.example.demo.controller;

import com.example.demo.model.Alien;
import com.example.demo.repository.AlienRepo;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@Controller
public class HomeController {

    @Autowired
    private AlienRepo alienRepo;

    @ModelAttribute
    public void modelData(Model m) {
        m.addAttribute("gender", "Boy");
    }

    @RequestMapping("/")
    public String home(){
        System.out.println("Welcome to the Home Page!");
        return "index";
    }

    @RequestMapping(value = "add", method = RequestMethod.POST)
    public String add(@RequestParam(value = "num1") int number1,
                      @RequestParam(value = "num2") int number2,
                      Model model) {
        model.addAttribute("sum", number1 + number2);
        return "result";
    }

    @RequestMapping(value="addAlien", method = RequestMethod.POST)
    public String addAlien(@ModelAttribute Alien alien) {
        return "alienResult";
    }

    @PostMapping(value = "addAlienToDatabase")
    public String addAlienToDatabase(@ModelAttribute Alien alien, Model model) {
        alienRepo.save(alien);
        model.addAttribute("dbAlienSaved", alien);
        return "alienResultAddedToDB";
    }

    @GetMapping(value = "getAliensFromDatabase")
    public String getAliensFromDatabase(Model model) {
        List<Alien> aliens = alienRepo.findAll();
        System.out.println("Aliens from database: " + aliens);
        model.addAttribute("alienList",aliens);
        return "showAliens";
    }
}
