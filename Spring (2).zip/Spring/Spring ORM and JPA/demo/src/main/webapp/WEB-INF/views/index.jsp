<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Insert title here</title>
</head>
<body>
    Welcome to Jaga!!
    <form action="add" method="post">
        <input type="text" name="num1" />
        <input type="text" name="num2" />
        <input type="submit" />
    </form>
    <br/>
    <form action="addAlien" method="post">
        Enter Alien ID: <input type="text" name="aid" /><br/>
        Enter Alien Name: <input type="text" name="aname" /><br/>
        <input type="submit" />
    </form>
    <br/>
    <form action="addAlienToDatabase" method="post">
        Enter Alien ID: <input type="text" name="aid" /><br/>
        Enter Alien Name: <input type="text" name="aname" /><br/>
        <input type="submit" />
    </form>
    <a href="getAliensFromDatabase">Get Aliens</a>
</body>
</html>