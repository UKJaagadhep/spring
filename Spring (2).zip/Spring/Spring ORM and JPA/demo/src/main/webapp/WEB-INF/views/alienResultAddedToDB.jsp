<%@ page language="java" contentType="text/html; charset=UTF-8"
         pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Insert title here</title>
</head>
<body>
Alien added!!<br/>
Alien ID: ${dbAlienSaved.aid}<br/>
Alien Name: ${dbAlienSaved.aname}<br/>
<a href="/">Go Back to Home Page</a>
</body>
</html>