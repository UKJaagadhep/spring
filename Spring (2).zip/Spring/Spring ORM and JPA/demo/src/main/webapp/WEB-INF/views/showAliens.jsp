<%@ page language="java" contentType="text/html; charset=UTF-8"
         pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Insert title here</title>
</head>
<body>
Welcome to ALIEN RESULT Page!!<br/>
Aliens retrieved from Database:<br/>
${alienList}<br/>
<table>
    <tr>
        <th>Alien ID</th>
        <th>Alien Name</th>
    </tr>
    <%
        java.util.List aliens = (java.util.List) request.getAttribute("alienList");
        if (aliens != null) {
            for (Object obj : aliens) {
                com.example.demo.model.Alien alien = (com.example.demo.model.Alien) obj;
    %>
    <tr>
        <td><%= alien.getAid() %></td>
        <td><%= alien.getAname() %></td>
    </tr>
    <%
            }
        }
    %>
</table>
<a href="/">Go Back to Home Page</a>
</body>
</html>
