public class NotesMVC {
    public static void main(String[] args) {
        System.out.println("This is a placeholder for the Spring NotesMVC class.");
    }
}

// SPRING MVC //

// 1. Controllers: Handle HTTP requests and return responses.
// 2. Services: Contain business logic and interact with repositories.
// 3. Repositories: Manage data access and persistence.
// 4. Models: Represent the data structures used in the application.
// 5. Configuration: Set up application settings, security, and other configurations.
// 6. Views: Define the user interface, often using templates like Thymeleaf or JSP.
// 7. Application Entry Point: The main class that bootstraps the Spring Boot application.
// 8. Filters and Interceptors: Manage cross-cutting concerns like logging, authentication, and request modification.
// 9. Exception Handling: Centralized management of application errors and exceptions.
// 10. Utilities: Helper classes and methods for common tasks.

// Model-View-Controller (MVC) is a design pattern used in software development to separate an application into three interconnected components: Model, View, and Controller. This separation helps manage complexity, promotes organized code, and enhances maintainability. Here's a brief overview of each component:
// 1. Model: The Model represents the data and business logic of the application. It is responsible for managing the data, including retrieving it from a database, processing it, and updating it. The Model is independent of the user interface and does not contain any information about how the data is presented to the user.
// 2. View: The View is responsible for displaying the data to the user. It defines the user interface and presentation layer of the application. The View retrieves data from the Model and renders it in a format suitable for user interaction, such as HTML pages, mobile app screens, or desktop application windows.
// 3. Controller: The Controller acts as an intermediary between the Model and the View. It handles user input, processes requests, and determines how to respond. The Controller receives input from the user (e.g., through forms or buttons), interacts with the Model to retrieve or update data, and then selects the appropriate View to display the results to the user.
// In summary, the MVC pattern helps organize code by separating concerns, allowing developers to work on different components independently, and making it easier to maintain and scale applications over time.

// In old servlet-based web applications, servlets acted as controllers, jsp files served as views, and JavaBeans or plain Java classes represented models. However, modern web applications often use frameworks like Spring MVC, which provide a more structured and feature-rich approach to implementing the MVC pattern.
// Each site or request of an application had its own controller which was a servlet. So a servlet was a single action controller. All the requests for a particular action were handled by a single servlet. This approach led to a increase in the number of servlets in the application making it difficult to manage them.

// So there is a need to have a controller which can handle multiple requests for different actions. This led to the introduction of Front Controller design pattern. In this pattern, a single controller handles all the requests for the application. This controller is called Front Controller.
// The Front Controller is responsible for handling all the requests for the application. It receives the request, processes it, and then forwards it to the appropriate handler (action controller) for further processing. The action controller is responsible for handling a specific action or request.
// It interacts with the model to retrieve or update data and then selects the appropriate view to display the results to the user.
// Or it redirects the request to another action controller for further processing. The action controller is responsible for handling a specific action or request.

// In Spring MVC, this Front Controller is implemented by the DispatcherServlet class. The DispatcherServlet is a servlet that acts as the front controller for the Spring MVC application. It receives all the requests for the application and then forwards them to the appropriate handler (controller) for further processing.
// The DispatcherServlet is configured in the web.xml file of the application. It is mapped to a specific URL pattern, such as /, which means that it will handle all the requests for the application.
// When a request is received by the DispatcherServlet, it first looks for a handler mapping that maps the request to a specific controller. The handler mapping is responsible for determining which controller should handle the request based on the URL pattern and other criteria.
// Once the appropriate controller is identified, the DispatcherServlet invokes the controller's method to handle the request. The controller processes the request, interacts with the model to retrieve or update data, and then selects the appropriate view to display the results to the user.
// Finally, the DispatcherServlet renders the view and sends the response back to the user.

// Have the spring-boot-starter-web dependency(Spring web) in your Maven or Gradle build file to set up a Spring MVC project quickly.

// We will create a webapp package under src/main and create a simple JSP file as our view. Then we will create a controller class to handle the request and return the view.
// 1. Create a JSP file named index.jsp under src/main/webapp/WEB-INF/views/
// 2. Create a controller class named HomeController.java under src/main/java/com/example/demo/controller/ (The name of the controller is conventionally named as the resource it is handling followed by 'Controller')

// In HomeController.java, you annotate the class with @Controller to indicate that it is a Spring MVC controller. This is a specialization of the @Component annotation, allowing Spring to detect it during component scanning and register it as a bean in the application context.
// It is used to define a controller that handles HTTP requests and returns views in a Spring MVC application. It has advantages like clear separation of concerns, easy integration with other Spring components, and support for various view technologies.

// In the home() method, you use the @RequestMapping("/") annotation to map HTTP requests to the root URL ("/") to this method. This means that when a user accesses the root URL of the application, this method will be invoked to handle the request.
// The home() method is a simple handler method that prints a welcome message to the console.

// We use @RequestMapping to map web requests to specific handler classes or methods in a Spring MVC application. It can be applied at both the class level and method level to define the URL patterns that the controller or method should handle.
// A single controller can handle multiple requests by defining multiple handler methods within the same controller class. Each method can be annotated with @RequestMapping (or other request mapping annotations) to specify the URL patterns and HTTP methods it should handle. This allows a single controller to manage different actions or resources based on the incoming requests.
// In the @RequestMapping annotation, you can specify various attributes such as value (URL pattern), method (HTTP method), params (request parameters), headers (request headers), consumes (content types), and produces (response content types) to further refine the request mapping.

// @RequestMapping can be used at both the class level and method level in a Spring MVC controller. When used at the class level, it defines a base URL for all the handler methods within that controller. When used at the method level, it specifies the URL pattern for that specific handler method.
// @RequestMapping is the parent annotation for several specialized request mapping annotations in Spring MVC, such as @GetMapping, @PostMapping, @PutMapping, @DeleteMapping, and @PatchMapping. These specialized annotations provide a more concise way to map specific HTTP methods to handler methods.

// To run JSP in Tomcat, we need to have tomcat-embed-jasper or tomcat-jasper dependency in our Maven or Gradle build file.
// It provides support for JSP compilation and execution in Tomcat server.
// In Spring Boot, we use tomcat-embed-jasper since it is an embedded Tomcat server.

// You also need to configure the view resolver to resolve the JSP views. In Spring Boot, you can do this by adding the following properties in application.properties file:
// spring.mvc.view.prefix=/WEB-INF/views/
// spring.mvc.view.suffix=.jsp

// If still the index.jsp page isn't loading in the url, just run 'gradlew clean booRun' to clean the build and start the application again.

// To display the JSP view when the home() method is invoked, you need to return the name of the view from the method. In this case, you would return "index" (the name of the JSP file without the .jsp extension).
// So the updated home() method would look like this:
// @RequestMapping("/")
// public String home(){
//     System.out.println("Welcome to the Home Page!");
//     return "index"; // Return the name of the view
// }

// This tells Spring MVC to look for a JSP file named index.jsp in the configured view location (/WEB-INF/views/) and render it as the response to the HTTP request.

// Say, we want to get 2 numbers as form input from the user and display their sum on a new page.
// We can create a form in the index.jsp file to take input from the user and submit it to a new controller method that will handle the addition and return the result view.
// Say if the form action is "add", we can create a new controller or a new method in the existing controller(since in spring a controller can handle multiple requests) to handle the request.
// It must have @RequestMapping("add") annotation to map the request to this method.
// In HomeController.java, we can add a new method to handle the addition request:
// @RequestMapping("/add")
// public String add(HttpServletRequest req){
//     int num1 = Integer.parseInt(req.getParameter("num1"));
//     int num2 = Integer.parseInt(req.getParameter("num2"));
//     int sum = num1+num2;
//     req.setAttribute("sum", sum);
//     return "result"; // Return the name of the result view (result.jsp)
// }
// We create result.jsp file under src/main/webapp/WEB-INF/views/ to display the sum.
// In the result.jsp file, we can access the sum attribute set in the request and display it to the user using Expression Language (EL):
// <h2>The sum is: ${sum}</h2>

// Spring provides various useful objects to a controller method to handle requests and responses. Some of the commonly used objects are:
// 1. HttpServletRequest: Represents the HTTP request and provides methods to access request parameters, headers, and attributes.
// 2. HttpServletResponse: Represents the HTTP response and provides methods to set response headers, status codes, and write response data.
// 3. Model: A container for passing data from the controller to the view. It allows you to add attributes that can be accessed in the view.
// 4. HttpSession: Represents the HTTP session and allows you to store and retrieve session attributes.
// 5. Principal: Represents the authenticated user and provides access to user details and roles.
// 6. HttpHeaders: Represents the HTTP headers of the request and provides methods to access header values.
// 7. Locale: Represents the locale of the request and allows you to access locale-specific information.
// 8. InputStream and OutputStream: Used for reading request data and writing response data, respectively.
// 9. ModelAndView: A container that holds both the model data and the view name to be rendered.
// 10. RedirectAttributes: Used to pass attributes during a redirect scenario.
// 11. ModelMap: Similar to Model, it is used to pass data from the controller to the view. It extends LinkedHashMap and provides additional methods for convenience.
// These objects can be injected into controller methods as parameters, allowing you to easily access and manipulate request and response data within your Spring MVC application.

// Besides this, we can also various annotated tags like:
// @RequestParam: To bind request parameters to method parameters for query strings and form data.
// @PathVariable: To bind URI template variables to method parameters for RESTful URLs.
// @RequestBody: To bind the request body to a method parameter.
// @ResponseBody: To indicate that the return value of a method should be used as the response body.
// @ModelAttribute: To bind request parameters to a model object.
// @SessionAttributes: To store model attributes in the HTTP session.
// @CookieValue: To bind cookie values to method parameters.
// These annotations simplify the process of handling HTTP requests and responses in Spring MVC applications.

// So the above add method can be rewritten using @RequestParam and Model as:
// @RequestMapping("/add")
// public String add(@RequestParam("num1") int num1, @RequestParam("num2") int num2, Model model){
//     int sum = num1 + num2;
//     model.addAttribute("sum", sum);
//     return "result"; // Return the name of the result view (result.jsp)
// }

// Here, the request parameters num1 and num 2 can be int or string. Spring will automatically convert them to the specified type.
// The Model object is used to add the sum attribute, which can be accessed in the result.jsp file using ${sum}.

// Equivalent version of above code using ModelAndView:
// @RequestMapping("/add")
// public ModelAndView add(@RequestParam("num1") int num1, @RequestParam("num2") int num2, ModelAndView mav){
//     //ModelAndView mav = new ModelAndView("result"); // Set the view name // You can also create ModelAndView object here instead of passing it as a parameter to the method
//     mav.setViewName("result"); // Set the view name
//     mav.addObject("sum", num1 + num2); // Add the sum attribute
//     return mav; // Return the ModelAndView object
// }

// Note: you can go to Spring application properties documentation to explore more properties to configure your Spring application.

// We may not always work with primitive data types like we did in the add method. We may need to work with complex data types like objects. In such cases, we can create a model class to represent the data structure and use it in the controller methods.
// For example, we can create a model class named Alien.java under src/main/java/com/example/demo/model/ to represent an alien with id and name attributes.
// Then we can create a form in the index.jsp file to take input for the alien object and submit it to a new controller method that will handle the request.
// In HomeController.java, we can add a new method to handle the alien request:
// @RequestMapping("/alien")
// public String alien(@ModelAttribute Alien alien){
//     return "alienResult"; // Return the name of the result view (alienResult.jsp)
// }
// We create alienResult.jsp file under src/main/webapp/WEB-INF/views/ to display the alien details.
// In the alienResult.jsp file, we can access the alien object and display its attributes using Expression Language (EL):
// <h2>Alien Details:</h2>
// <p>ID: ${alien.aid}</p>
// <p>Name: ${alien.aname}</p>
// Here, the @ModelAttribute annotation is used to bind the request parameters to the Alien object.
// Spring will automatically populate the object with the request data based on the parameter names matching the object attributes.
// If I just use ${alien} in alienResult.jsp, it will call the toString() method of the Alien class and display the string representation of the object.

// If we want to access the alien id and name with different names in alienResult.jsp like a1.aid and a1.aname, we can specify a name in the @ModelAttribute annotation like @ModelAttribute("a1") Alien alien.

// @ModelAttribute need not only be used as a method parameter annotation. It can also be used at the method level to add attributes to the model before any handler method is invoked.
// When used at the method level, the annotated method is invoked before any handler method in the controller is executed.
// The return value of the method is added to the model and is accessible in all handler methods in that controller.
// For example:
// @ModelAttribute
// public void modelData(Model m){
//     m.addAttribute("gender", "Boy");
// }
// Here, the modelData() method is annotated with @ModelAttribute at the method level.
// It adds a gender attribute to the model with the value "Boy".
// This attribute will be accessible in all handler methods in the HomeController class.
// So in index.jsp, result.jsp, alienResult.jsp files, we can access the gender attribute using ${gender}.
// This is useful for adding common data that needs to be available across multiple handler methods in the controller.

// We can also access Alien id and name in index.jsp and result.jsp using ${alien.aid} and ${alien.aname} since the modelData() method is invoked before any handler method in the controller is executed.
// But the values will be null if the alien object is not populated yet.

// Note: You can also use @SessionAttributes at the class level to store model attributes in the HTTP session.
// This is useful for maintaining data across multiple requests from the same user while @ModelAttribute is used for a single request.


