public class NotesJDBC {
    public static void main(String[] args) {
        System.out.println("This file contains notes on Spring JDBC.");
    }
}

// SPRING JDBC //

// Spring JDBC is a module of the Spring Framework that provides a simplified and consistent way to interact with relational databases using JDBC (Java Database Connectivity).

// In regular JDBC, everytime you send a request to the database, a new connection is created and destroyed after the operation is complete.
// This can lead to performance issues, as creating and destroying connections is a time-consuming process.
// To solve this problem, Spring JDBC provides a connection pooling mechanism that allows for reusing existing connections instead of creating new ones for each request.
// This improves performance and reduces the overhead of managing database connections.

// We use a DataSource to manage the database connections in Spring JDBC.
// A DataSource is an interface that provides a way to obtain database connections.
// DataSource has its configs and provides connection pooling where multiple connections are created and managed in a pool.
// When a request for a connection is made, a connection is obtained from the pool instead of creating a new one.
// After the operation is complete, the connection is returned to the pool for reuse.
// This allows for efficient management of database connections and improves the performance of database operations.

// Also instead of writing boilerplate code for handling exceptions, closing connections, statements, and result sets, Spring JDBC provides the JdbcTemplate class.
// JdbcTemplate is a helper class that simplifies the process of executing SQL queries and updates.
// It handles the boilerplate code for you and provides a simple API for executing SQL operations.
// It also helps you with the DataSource management and connection pooling.

// In spring initializer from spring.io, we can add the dependency for spring JDBC by selecting the "JDBC API" and the database driver we want to use (e.g., MySQL, PostgreSQL, etc.).
// We will use H2 database in thsi example which is an in-memory database that is easy to set up and use for development and testing purposes.
// Some databases require us to manually add the dependency for the database driver in the pom.xml file (for Maven projects) or build.gradle file (for Gradle projects).

// We specify the database connection properties like username, password, driver and url in the application.properties file as spring.datasource.username, spring.datasource.password, spring.datasource.driver-class-name and spring.datasource.url respectively.

// We will create a sample class Alien to represent the data we want to store in the database in model package.
// package com.example.demo.model;
// public class Alien {
//     private int id;
//     private String name;
//     private String tech;
//     // Getters and Setters
// }

// We use the model package to store all the classes that represent the data we want to store in the database or used in our application.

// We don't annotate these model classes with @Component as these are not application level beans managed by the Spring container.
// These are just simple POJO (Plain Old Java Object) classes that represent the data structure and are instantiated per request as needed.
// Or we use the scope as @Scope("prototype") if we want Spring to manage these beans but create a new instance for each request.

// In a normal application, we will have multiple layers like Controller, Service, Repository/DAO etc.
// The Controller layer handles the incoming requests and sends responses.
// The Service layer contains the business logic of the application.
// The Repository/DAO layer handles the database operations.
// So we will call the controller layer from the main application class, the controller layer will call the service layer, and the service layer will call the repository/DAO layer to perform database operations.

// We will create a Repository/DAO class AlienRepo in the repository package to handle the database operations related to the Alien model.
// We will have methods like save, findAll etc. in the AlienRepo class to perform database operations.
// We will annotate the AlienRepo class with @Repository to indicate that it is a repository/DAO class.
// The @Repository annotation is a specialization of the @Component annotation and is used to indicate that the class is a repository/DAO class.
// Its advantage is that it provides automatic exception translation i.e. it translates the low-level database exceptions into Spring's DataAccessException hierarchy.

// We will use the JDBC Template class to perform database operations in the AlienRepo class.
// We can inject the JdbcTemplate bean into the AlienRepo class using @Autowired annotation.
// The JdbcTemplate bean is automatically configured by Spring Boot based on the database connection properties specified in the application.properties file.
// In our save method, we will use the update method of the JdbcTemplate class to insert data into the database.
// In our findAll method, we will use the query method of the JdbcTemplate class to retrieve data from the database.

// Example of save method:
// public void save(Alien alien){
//     String sql = "INSERT INTO alien (id, name, tech) VALUES (?, ?, ?)";
//     template.update(sql, alien.getId(), alien.getName(), alien.getTech()); //returns number of rows affected
// }

// We can have a schema.sql file in the src/main/resources folder to create the necessary database tables when the application starts.
// Spring Boot automatically executes the schema.sql file to create the database schema at startup.
// In our case, we can have the following schema.sql file to create the alien table:
// CREATE TABLE alien (
//     id INT PRIMARY KEY,
//     name VARCHAR(50),
//     tech VARCHAR(50)
// );

// We can also have a data.sql file in the src/main/resources folder to insert some initial data into the database when the application starts.
// Spring Boot automatically executes the data.sql file to insert the initial data at startup.
// In our case, we can have the following data.sql file to insert some initial data into the alien table:
// INSERT INTO alien (id, name, tech) VALUES (1, 'Yash', 'Java');
// INSERT INTO alien (id, name, tech) VALUES (2, 'Aman', 'Python');
// INSERT INTO alien (id, name, tech) VALUES (3, 'Ravi', 'JavaScript');

// Both schema.sql and data.sql files are optional. If we don't have them, we can create the database schema and insert data programmatically using the JdbcTemplate class.
// If we already have an existing database with the necessary schema and data, we don't need to have these files.

// To retrieve data from the database, we can use the query method of the JdbcTemplate class.
// The query method takes a SQL query and a RowMapper or a ResultSetExtractor or RowCallbackHandler to map the result set to the desired object.
// A RowMapper is an functional interface that maps a single row of the result set to an object.
// It has a single method mapRow(ResultSet rs, int rowNum) that takes a ResultSet and the row number as parameters and returns the mapped object.
// The mapRow method is called for each row in the result set and the mapped objects are collected into a list and returned by the query method.
// We can use a lambda expression to implement the RowMapper interface and map the result set to the Alien object.
// Example of findAll method:
// public List<Alien> findAll(){
//     String sql = "SELECT * FROM alien";
//     RowMapper<Alien> mapper = (rs, rowNum) -> {
//         Alien alien = new Alien();
//         alien.setId(rs.getInt("id"));
//         alien.setName(rs.getString("name"));
//         alien.setTech(rs.getString("tech"));
//         return alien;
//     };
//     List<Alien> aliens = template.query(sql, mapper); //query method returns List<T>
//     return aliens;
// }

// Here we haven't specified the database connection details like username, password, driver and url anywhere in application.properties file because we are using H2 in-memory database.

//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------