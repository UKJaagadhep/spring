insert into alien (id, name, tech) values (1, 'Zorg', 'Invisibility');
insert into alien (id, name, tech) values (2, 'Xenon', 'Teleportation');
insert into alien (id, name, tech) values (3, 'Blip', 'Time Travel');