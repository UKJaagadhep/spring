package com.example.demo.repository;

import com.example.demo.model.Alien;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class AlienRepo {
    private JdbcTemplate template;

    public JdbcTemplate getTemplate() {
        return template;
    }

    @Autowired
    public void setTemplate(JdbcTemplate template) {
        this.template = template;
    }

    public void save(Alien alien){
        String sql = "Insert into alien(id,name,tech) values(?,?,?)";
        int numRows = template.update(sql,alien.getId(),alien.getName(),alien.getTech());
        System.out.println(numRows+" row(s) inserted.");
    }

    public List<Alien> findAll(){
        String sql = "Select * from alien";
        RowMapper<Alien> mapper = (rs, rowNum) -> {
            Alien a = new Alien();
            a.setId(rs.getInt("id"));
            a.setName(rs.getString("name"));
            a.setTech(rs.getString("tech"));
            return a;
        };
        List<Alien> aliens = template.query(sql,mapper);
        return aliens;
    }
}
