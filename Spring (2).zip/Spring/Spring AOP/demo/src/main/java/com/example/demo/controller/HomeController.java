package com.example.demo.controller;

import com.example.demo.model.Alien;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.IOException;

@Controller
public class HomeController {

    @ModelAttribute
    public void modelData(Model m) {
        m.addAttribute("gender", "Boy");
    }

    @RequestMapping("/")
    public String home(){
        System.out.println("Welcome to the Home Page!");
        return "index";
    }

    @RequestMapping(value = "add", method = RequestMethod.POST)
    public String add(@RequestParam(value = "num1") int number1,
                      @RequestParam(value = "num2") int number2,
                      Model model) {
        model.addAttribute("sum", number1 + number2);
        return "result";
    }

    @RequestMapping(value="addAlien", method = RequestMethod.POST)
    public String addAlien(@ModelAttribute Alien alien) {
        return "alienResult";
    }
}
