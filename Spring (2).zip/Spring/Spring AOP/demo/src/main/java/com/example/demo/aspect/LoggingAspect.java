package com.example.demo.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

    private static final Logger log = LoggerFactory.getLogger(LoggingAspect.class);

    public LoggingAspect() {
        log.info("Constructing LoggingAspect: {}", System.identityHashCode(this));
    }

    // Log only HTTP handler methods (Get/Post/Put/Delete/Patch/RequestMapping)
    @Before( //Others include @After, @Around, @AfterReturning, @AfterThrowing
            "(" +
                    "@annotation(org.springframework.web.bind.annotation.GetMapping) || " +
                    "@annotation(org.springframework.web.bind.annotation.PostMapping) || " +
                    "@annotation(org.springframework.web.bind.annotation.PutMapping) || " +
                    "@annotation(org.springframework.web.bind.annotation.DeleteMapping) || " +
                    "@annotation(org.springframework.web.bind.annotation.PatchMapping) || " +
                    "@annotation(org.springframework.web.bind.annotation.RequestMapping)" +
                    ")"
    )
    public void getLog(JoinPoint jp) {
        Object target = jp.getTarget();
        log.info(
                "HTTP handler invoked | aspect@{} | targetClass={} | target@{} | method={}",
                System.identityHashCode(this),
                target != null ? target.getClass().getName() : "null",
                target != null ? System.identityHashCode(target) : -1,
                jp.getSignature()
        );
    }
}