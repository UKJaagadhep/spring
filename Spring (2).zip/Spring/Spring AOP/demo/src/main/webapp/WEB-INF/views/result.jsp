<%@ page language="java" contentType="text/html; charset=UTF-8"
         pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Insert title here</title>
</head>
<body>
Welcome to RESULT Page!!<br/>
The result is: ${sum}<br/>
Gender: ${gender}<br/>
<a href="/">Go Back to Home Page</a>
</body>
</html>