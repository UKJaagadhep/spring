<%@ page language="java" contentType="text/html; charset=UTF-8"
         pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Insert title here</title>
</head>
<body>
Welcome to ALIEN RESULT Page!!<br/>
Alien ID: ${alien.aid}<br/>
Alien Name: ${alien.aname}<br/>
Alien Gender: ${gender}<br/>
<a href="/">Go Back to Home Page</a>
</body>
</html>