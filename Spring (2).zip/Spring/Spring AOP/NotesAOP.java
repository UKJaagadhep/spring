public class NotesAOP {
    public static void main(String[] args) {
        System.out.println("Spring AOP");
    }
}

// SPRING AOP //

// Note: We will use the Spring MVC project we created to showcase AOP concepts, but the AOP concepts are not limited to Spring MVC. They can be applied to any Spring application.

// There are some things which can be applied to multiple classes, such as logging, security, transactions, etc.
// These are called cross-cutting concerns.
// AOP (Aspect-Oriented Programming) is a programming paradigm that allows us to separate these cross-cutting concerns from the main business logic of our application.

// In Spring, AOP is implemented using proxies.
// A proxy is a class that wraps around another class and intercepts method calls to that class.
// There are two types of proxies in Spring AOP:
// 1. JDK Dynamic Proxies: These are used when the target class implements an interface. The proxy will implement the same interface and delegate method calls to the target class.
// 2. CGLIB Proxies: These are used when the target class does not implement an interface. The proxy will create a subclass of the target class and override its methods to intercept method calls.

// In Spring AOP, we define aspects, which are classes that contain advice (the code to be executed) and pointcuts (the conditions under which the advice should be executed).
// Pointcuts can be defined using expressions that match method signatures, such as execution(* com.example.service.*.*(..)) to match all methods in the com.example.service package or execution(* com.example.service.*.get*(..)) to match all getter methods in the com.example.service package.
// We can also have individual methods like @After("execution(*(for return type) com.example.controller.HomeController.add(..))") to match a specific method in a specific class.
// There are three types of advice in Spring AOP:
// 1. Before Advice: This advice is executed before the method execution.
// 2. After Advice: This advice is executed after the method execution, regardless of the outcome (whether it returns normally or throws an exception). After can also be further categorized into After Returning (executed only if the method returns normally) and After Throwing (executed only if the method throws an exception).
// 3. Around Advice: This advice is executed around the method execution, allowing us to control when the method is executed and to modify the return value or handle exceptions.
// To define an aspect in Spring, we can use the @Aspect annotation on a class and the @Before, @After, or @Around annotations on methods to define the advice.

// A join point is a point during the execution of a program, such as the execution of a method or the handling of an exception, where an aspect can be applied.
// Some examples of join points include method execution, method call, field access, exception handling, etc.

// Weaving is the process of applying aspects to a target object to create a proxy object that contains the advice defined in the aspect. This can be done at compile time, load time, or runtime, depending on the AOP framework being used.
// We can also weave aspects using Spring AOP, which uses runtime weaving to create proxies for the target objects and apply the advice defined in the aspects.

// Example of a simple aspect that logs method execution:
// @Aspect
// @Component // as Aspect isn't a Component, we need to annotate it with @Component to make it a Spring bean
// public class LoggingAspect {
//     @Before("execution(* com.example.service.*.*(..))") // Pointcut expression to match all methods in the com.example.service package
//     public void logBefore(JoinPoint joinPoint) {
//         System.out.println("Executing method: " + joinPoint.getSignature().getName());
//     }
// }

// Have the spring-boot-starter-aop dependency in build.gradle.

// Your application code won't even know that the aspect is there, and it won't have to do anything to use it.
// The aspect will be applied automatically to the target objects based on the pointcut expressions defined in the aspect.
// This allows us to keep our application code clean and focused on the business logic, while the cross-cutting concerns are handled separately in the aspects.

// We have a Logger class that we want to use to log method execution in our application. We can define an aspect that uses this Logger to log method execution without having to modify our application code.
// @Aspect
// @Component
// public class LoggingAspect {
//     private Logger logger = (Logger) LoggerFactory.getLogger(LoggingAspect.class);
//
//     @Before("execution(* com.example.service.*.*(..))")
//     public void logBefore(JoinPoint joinPoint) {
//         logger.info("Executing method: " + joinPoint.getSignature().getName()); // info is logging level, we can also use debug, error, warn, etc.
//     }
// }

// You can provide various specifications regaring logging in application.properties, such as logging level, log file location, log pattern, etc.
// logging.level.com.example=DEBUG
// logging.file.name=app.log
// logging.pattern.console=%d{yyyy-MM-dd HH:mm:ss} - %msg%n

// You can also change the color of the logs in the console by using ANSI escape codes in the log pattern.
// Changing color code:
// logging.pattern.console=%d{yyyy-MM-dd HH:mm:ss} - %highlight(%msg%n) // highlight will automatically change the color based on the log level (ERROR=red, WARN=yellow, INFO=green, DEBUG=blue, etc.)


