package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Alien {
    @Autowired
    private Laptop lap;
    @Value("${alien.id}")
    private int id;
    public void code() {
        System.out.println("Alien " + id + " coding...");
        lap.compile();
    }
}
