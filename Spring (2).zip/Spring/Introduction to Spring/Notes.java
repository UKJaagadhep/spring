public class Notes{
    public static void main(String[] args){
        System.out.println("Notes");
    }
}

// SPRING //
// Spring is a java framework used for building enterprise-level applications.
// Earlier, we had different frameworks for different purposes like struts for web applications, jpa for database handling, hibernate for ORM, etc.
// But with Spring, we can use a single framework for all these purposes.

// Spring focuses on POJO (Plain Old Java Object) programming model and Dependency Injection (DI) design pattern.
// Dependency Injection is a design pattern in which an object receives other objects that it depends on, called dependencies, from an external source rather than creating them itself.
// This helps in achieving loose coupling between classes and makes the code more testable and maintainable.

// Spring provides various modules like Spring Core, Spring MVC, Spring Data, Spring Security, etc., to cater to different needs of application development.
// We use Spring Core for dependency injection, Spring MVC for building web applications, Spring Data for database operations, Spring REST for building RESTful web services, and Spring Security for securing applications etc.

// When running Spring MVC applications, we typically use a servlet container like Apache Tomcat or Jetty to host the application.
// So ultimately, they get converted to servlets that run on these containers.

// In IntelliJ community edition, we cannot create Spring projects directly as it does not have built-in support for Spring.
// However, we can create a Maven or Gradle project and then add the necessary Spring dependencies to the build file (pom.xml for Maven or build.gradle for Gradle) to set up a Spring project.
// Alternatively, we can use Spring Initializr (https://start.spring.io/) to generate a Spring Boot project with the required dependencies and then import it into IntelliJ.

// Spring Starter Project is a collection of Spring modules that can be used to build Spring applications. It provides a set of pre-configured dependencies and configurations to simplify the setup process for different types of applications.
// Some popular Spring Starter Projects include:
// 1. spring-boot-starter-web: For building web applications, including RESTful services.
// 2. spring-boot-starter-data-jpa: For working with JPA and database operations.
// 3. spring-boot-starter-security: For adding security features to applications.
// 4. spring-boot-starter-test: For testing Spring applications.
// 5. spring-boot-starter-thymeleaf: For building web applications with Thymeleaf templating engine.
// These starter projects help developers quickly set up their applications with the necessary dependencies and configurations, allowing them to focus on writing business logic rather than dealing with boilerplate code.

// Spring Legacy Project refers to the older versions of the Spring Framework that were used before the introduction of Spring Boot.
// These versions required more manual configuration and setup compared to the modern Spring Boot approach.
// In a Spring Legacy Project, developers had to configure various components like the application context, data sources, transaction management, etc., using XML configuration files or Java-based configuration classes.
// This often led to more boilerplate code and a steeper learning curve for new developers.
// With the advent of Spring Boot, many of these configurations are now auto-configured, making it easier and faster to develop Spring applications.

// If creating a Spring project in a Maven repository, we need to include the necessary dependencies in the pom.xml file.
// For example, to create a Spring Boot web application, we would include the following dependencies:
// 1. spring-boot-starter-web
// 2. spring-boot-starter-data-jpa
// 3. spring-boot-starter-security
// 4. spring-boot-starter-test

// The Spring Context dependency is a core module of the Spring Framework that provides the ApplicationContext interface.
// The ApplicationContext is responsible for managing the lifecycle of beans, handling dependency injection, and providing various services like event propagation, resource loading, and internationalization.
// Resource loading is the process of loading external resources like files, classpath resources, etc., into the application context.
// Internationalization (i18n) is the process of designing an application to support multiple languages and cultures by providing localized messages and resources based on the user's locale.
// The Spring Context module also provides support for AOP (Aspect-Oriented Programming) and transaction management.
// The ApplicationContext acts as a central registry for all the beans in a Spring application and allows developers to retrieve and manage them using their names or types.
// The Spring Core is included in Spring Context.

// Besides the Spring Core, the Spring Context module also includes other important components like:
// 1. ApplicationContext - The main interface for managing the lifecycle of beans
// 2. BeanFactory - The root interface for accessing the Spring container
// 3. BeanFactoryPostProcessor - Allows for custom modification of bean definitions before they are instantiated
// 4. BeanPostProcessor - Allows for custom modification of beans after they are instantiated
// 5. Environment - Provides access to environment properties and profiles
// 6. ResourceLoader - Provides a way to load resources like files and classpath resources

// The spring-boot-starter module is a convenient way to include the core Spring Boot dependencies in a project. So you don't have to specify spring core, spring context etc. separately.

// Bean is an object that is managed by the Spring IoC (Inversion of Control) container.
// In Spring, a bean is simply a Java object that is instantiated, assembled, and managed by the Spring container.
// Beans are defined in the Spring configuration file (XML or Java-based configuration) and can be injected into other beans using dependency injection.
// Beans can have different scopes, such as singleton (one instance per Spring container), prototype (multiple instances), or request (one instance per HTTP request).
// Beans are the building blocks of a Spring application and are used to represent various components like services, repositories, controllers, etc.

// Inversion of Control (IoC) is a design principle in which the control of object creation and management is transferred from the application code to an external framework or container.
// In the context of Spring, IoC is implemented through the use of the Spring IoC container, which is responsible for creating, configuring, and managing the lifecycle of beans.
// With IoC, the application code does not need to worry about creating and managing objects, as this responsibility is delegated to the Spring container.
// This leads to loose coupling between components, as they do not need to know about the instantiation and lifecycle of their dependencies.
// IoC is often implemented using Dependency Injection (DI), where dependencies are injected into a class rather than being created by the class itself.

//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// DEPENDENCY INJECTION IN SPRING //

// Normally to create an object of class Alien in Java, we would do:
// Alien a = new Alien();
// This makes the developer responsible for creating the object and managing its lifecycle.
// In Spring, the IoC container takes care of creating and managing the lifecycle of beans (objects). We can do this by:
// Alien a = context.getBean(Alien.class); //context is ApplicationContext object we need to get from SpringApplication.run() method
// Here, the context is the Spring ApplicationContext that manages the beans.
// The IoC container creates the object of class Alien and manages its lifecycle, relieving the developer of this responsibility.
// This allows for better separation of concerns and makes the code more testable and maintainable.

// SpringApplication.run(DemoApplication.class, args); returns an instance of ApplicationContext, which is the Spring IoC container.
// We can use this ApplicationContext instance to get beans managed by the Spring container.
// For example:
// ApplicationContext context = SpringApplication.run(DemoApplication.class, args);
// Alien a = context.getBean(Alien.class);
// Here, we are retrieving the bean of type Alien from the Spring container using the getBean method.
// The ApplicationContext is responsible for managing the lifecycle of beans and providing them to the application as needed.

// But for the above code to work, we need to tell Spring that the class Alien is a bean that needs to be managed by the Spring container.
// We can do this by adding the @Component annotation to the Alien class:
// @Component
// public class Alien {
//     public void code() {
//         System.out.println("Alien coding...");
//     }
// }
// The @Component annotation tells Spring that this class is a component (bean) that needs to be managed by the Spring container.
// Now, when we call context.getBean(Alien.class), Spring will create an instance of the Alien class and manage its lifecycle.
// Note: We also need to ensure that the package containing the Alien class is scanned by Spring. This is typically done by placing the Alien class in the same package or a sub-package of the main application class annotated with @SpringBootApplication.

// @SpringBootApplication is a convenience annotation that combines three annotations:
// 1. @Configuration: Indicates that the class can be used by the Spring IoC container as a source of bean definitions.
// 2. @EnableAutoConfiguration: Tells Spring Boot to start adding beans based on classpath settings, other beans, and various property settings.
// 3. @ComponentScan: Tells Spring to scan the current package and its sub-packages for components, configurations, and services, allowing it to find the beans to manage.
// By using @SpringBootApplication, we can simplify the configuration of our Spring Boot application and enable auto-configuration and component scanning with a single annotation.

//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// SPRING BOOT AUTOWIRE //

// In Spring, @Autowired is an annotation used for automatic dependency injection.
// It allows Spring to resolve and inject collaborating beans into our bean.
// When we annotate a field, constructor, or setter method with @Autowired, Spring will automatically find the appropriate bean in the application context and inject it into the annotated member.
// This helps to reduce boilerplate code and makes it easier to manage dependencies between beans.
// For example:
// @Component
// public class Alien {
//     @Autowired
//     private Laptop laptop; // Normally we would do private Laptop laptop = new Laptop(); but with @Autowired, Spring will inject the Laptop bean automatically. The Laptop class must have the @Component annotation for this to work.
//
//     public void code() {
//         laptop.compile();
//         System.out.println("Alien coding...");
//     }
// }
// In this example, the Laptop bean will be automatically injected into the Alien bean by Spring.

// Note: For @Autowired to work, the class being injected (Laptop in this case) must also be a Spring-managed bean, typically annotated with @Component or another stereotype annotation.

// @Autowired is preferred over manual instantiation (using new keyword) because it promotes loose coupling and makes the code more testable and maintainable.
// With @Autowired, the dependencies are managed by the Spring container, allowing for easier swapping of implementations and better separation of concerns.
// It also reduces boilerplate code, as we don't have to manually create and manage the dependencies ourselves.
// Additionally, @Autowired supports various injection strategies (by type, by name, etc.) and can be used with constructor injection, setter injection, or field injection, providing flexibility in how dependencies are injected.
// It will serve as a huge advantage when working with big projects with many interdependent classes.

//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// SPRING BEAN FACTORY //

// Spring allows more customization than Spring Boot's auto-configuration by using the BeanFactory interface.
// BeanFactory is the root interface for accessing the Spring container.
// It provides basic functionality for managing beans, such as instantiating, configuring, and assembling them.
// With BeanFactory, developers have more control over the bean lifecycle and can customize the way beans are created and managed.

// BeanFactory is a more low-level interface compared to ApplicationContext.
// While ApplicationContext extends BeanFactory and provides additional features like internationalization, event propagation, and resource loading, BeanFactory focuses solely on bean management.
// So BeanFactory was used in earlier versions of Spring before ApplicationContext was introduced.
// However, in modern Spring applications, ApplicationContext is the preferred choice as it provides a more comprehensive set of features for building enterprise-level applications.
// In summary, while BeanFactory allows for more customization, ApplicationContext is generally recommended for most Spring applications due to its additional features and ease of use.

// Example code:
// import org.springframework.beans.factory.BeanFactory;
// import org.springframework.beans.factory.xml.XmlBeanFactory;
// public class App{
//   public static void main(String[] args){
//     BeanFactory factory = new XmlBeanFactory(new FileSystemResource("spring.xml"));
//     Alien obj = (Alien) factory.getBean("alien");
//     obj.code();
//   }
// }

// Here, the spring.xml (on same level as pom.xml or gradle.build) file contains the bean definitions and configurations.
// Sample spring.xml file:
// <beans>
//   <bean id="alien" class="com.example.demo.Alien"/> // can also specify scope, init-method, destroy-method etc.
// </beans>

// Note: XmlBeanFactory is deprecated as of Spring 3.1. It is recommended to use ClassPathXmlApplicationContext or FileSystemXmlApplicationContext instead for XML-based configuration.

//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// APPLICATION CONTEXT //

// ApplicationContext is a more advanced and feature-rich interface compared to BeanFactory.
// It extends the BeanFactory interface and provides additional functionalities such as:
// 1. Internationalization (i18n) support: Allows for easy localization of messages and resources based on the user's locale.
// 2. Event propagation: Supports event-driven programming by allowing beans to publish and listen for events.
// 3. Resource loading: Provides a way to load resources like files, classpath resources, etc.
// 4. Bean lifecycle management: Provides more advanced lifecycle management features like bean post-processors and lifecycle callbacks.
// 5. Integration with Spring AOP: Allows for aspect-oriented programming features to be easily integrated with beans.
// Due to these additional features, ApplicationContext is the preferred choice for most Spring applications.
// It provides a more comprehensive and convenient way to manage beans and their dependencies, making it easier to build complex enterprise-level applications.

// Example code:
// import org.springframework.context.ApplicationContext;
// import org.springframework.context.support.ClassPathXmlApplicationContext;
// public class App{
//   public static void main(String[] args){
//     ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml"); // spring.xml should be in classpath (e.g., in src/main/resources folder)
//     Alien obj = (Alien) context.getBean("alien");
//     obj.code();
//   }
// }

//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// SPRING CONTAINER //

// The Spring Container is the core component of the Spring Framework that is responsible for managing the lifecycle of beans and their dependencies.
// It is implemented through the ApplicationContext interface, which provides a way to configure, instantiate, and manage beans in a Spring application.
// The Spring Container is responsible for:
// 1. Instantiating beans: Creating instances of beans based on their definitions in the configuration file or annotations.
// 2. Configuring beans: Setting properties and dependencies of beans based on their definitions.
// 3. Managing bean lifecycle: Handling the initialization and destruction of beans, as well as managing their scopes (singleton, prototype, etc.).
// 4. Providing dependency injection: Injecting dependencies into beans based on their definitions.
// The Spring Container is typically created at the start of a Spring application and remains active throughout the application's lifecycle.
// It provides a central registry for all the beans in the application and allows developers to retrieve and manage them as needed.
// Overall, the Spring Container is a crucial component of the Spring Framework that enables the powerful features of dependency injection and inversion of control.

// So the constructor of the beans is called by the Spring Container when it is created by the ApplicationContext unless specified otherwise like using @Lazy annotation for lazy initialization or using prototype scope for the bean.
// So in above code, the constructor for Alien class will be called when we do ApplicationContext context = SpringApplication.run(DemoApplication.class, args); itself.
// The Spring Container is created when we call SpringApplication.run() method in a Spring Boot application when ApplicationContext is returned.

// The Spring Container is present in the JVM memory as long as the application is running.
// It has the Spring Beans in its memory and manages their lifecycle.
// When the application is stopped or terminated, the Spring Container is destroyed and all the beans managed by it are also destroyed.

// In the given code:
// Alien obj1 = (Alien) context.getBean("alien");
// Alien obj2 = (Alien) context.getBean("alien");
// Here, both obj1 and obj2 will refer to the same instance of the Alien bean.
// This is because, by default, Spring beans are singleton-scoped, meaning that only one instance of the bean is created and shared across the application.
// So when we call context.getBean("alien") multiple times, we get the same instance of the Alien bean.
// If we want to create a new instance of the bean each time we call getBean(), we can change the scope of the bean to prototype by using the @Scope("prototype") annotation on the Alien class.
// Example:
// @Component
// @Scope("prototype")
// public class Alien {

// In prototype scope, the bean will be created each time it is requested from the Spring Container using getBean() method and not during the container initialization using SpringApplication.run() method like singleton scope.

//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// SETTER INJECTION //

// You can pass values to beans for constuctor using constructor injection or setter injection.
// Setter injection is a type of dependency injection where the dependencies are provided to a bean through setter methods.
// In setter injection, the Spring container calls the setter methods of the bean after it has been instantiated to set the values of its properties.
// This allows for more flexibility in configuring the bean, as the properties can be set in any order and can be changed at runtime if needed.
// Example:
// @Component
// public class Alien {
//     private int id;
//     private String name;
//
//     public void setId(int id) {
//         this.id = id;
//     }
//
//     public void setName1(String name) {
//         this.name = name;
//     }
// }

// In this example, the Alien class has two properties: id and name. The setter methods setId() and setName1() are used to set the values of these properties.
// The Spring container will call these setter methods after creating an instance of the Alien bean to set the values of id and name.
// To set values for this bean, we can use XML configuration or Java-based configuration.
// Example using XML configuration:
// <bean id="alien" class="com.example.demo.Alien">
//     <property name="id" value="1"/>
//     <property name="name1" value="Nielson"/> // If the value is an object instead of a primitive type or String, we can use ref instead of value and provide the id of the bean to be injected. ref can also refer a child class bean.
// </bean>

// To set the values of these properties, we can also use the @Value annotation in the configuration file or Java-based configuration.
// Example using @Value annotation:
// @Component
// public class Alien {
//     private int id;
//     private String name;
//
//     @Value("${alien.id}")
//     public void setId(int id) {
//         this.id = id;
//     }
//
//     @Value("${alien.name}")
//     public void setName1(String name) {
//         this.name = name;
//     }
// }
// Here, the @Value annotation is used to inject the values of alien.id and alien.name from the application properties file into the setter methods.
// This allows us to easily configure the properties of the Alien bean without hardcoding the values in the code.
// The values will be read from application.properties file present in src/main/resources folder.
// Example application.properties file:
// alien.id=1
// alien.name=Nielson

// Note: In setter injection, the dependencies are optional, meaning that if a property is not set, the bean can still be created without it. However, if a required property is not set, it may lead to runtime errors.

// For passing objects as dependencies using setter injection, we can do it like this in XML configuration:
// <bean id="laptop" class="com.example.demo.Laptop"/>
// <bean id="alien" class="com.example.demo.Alien">
//     <property name="id" value="1"/>
//     <property name="name1" value="Nielson"/>
//     <property name="laptop" ref="laptop"/> // Here, we are injecting the Laptop bean into the Alien bean using the ref attribute.
// </bean>

// We can use the autowired property in spring.xml like this:
// <bean id="laptop" class="com.example.demo.Laptop"/>
// <bean id="alien" class="com.example.demo.Alien" autowire="byName">
//     <property name="id" value="1"/>
//     <property name="name1" value="Nielson"/>
// </bean>
// Here, the autowire="byName" attribute tells Spring to automatically inject the Laptop bean into the Alien bean based on the property name.
// The variable name laptop in Alien class should match the bean id laptop in spring.xml for byName to work.
// Instead of byName, we can also use autowire="byType" to inject the dependency based on the type of the property so that we can also use child classes.
// But there must be only one bean of that type in the container for this to work unless we use @Primary annotation on one of the beans of that type or specify primary="true" in spring.xml for that bean to indicate that it should be used as the default bean for autowiring.

// If we use both autowired property and property tag for the same property, then the property tag will take precedence over autowiring.


// We can also do the same using @Autowired annotation on the setter method like this:
// @Component
// public class Alien {
//     private int id;
//     private String name;
//     private Laptop laptop;
//
//     @Value("${alien.id}")
//     public void setId(int id) {
//         this.id = id;
//     }
//
//     @Value("${alien.name}")
//     public void setName1(String name) {
//         this.name = name;
//     }
//
//     @Autowired
//     public void setLaptop(Laptop laptop) {
//         this.laptop = laptop;
//     }
// }
// Here, the @Autowired annotation is used to inject the Laptop bean into the Alien bean using the setLaptop() setter method.
// The Spring container will call this setter method after creating an instance of the Alien bean to set the value of the laptop property.
// This allows us to easily inject dependencies into the Alien bean without hardcoding the values in the code.

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// CONSTRUCTOR INJECTION //

// Constructor injection is a type of dependency injection where the dependencies are provided to a bean through its constructor.
// In constructor injection, the Spring container calls the constructor of the bean and passes the required dependencies as arguments.
// This allows for better immutability and ensures that the dependencies are provided at the time of bean creation.
// Example:
// @Component
// public class Alien {
//     private int id;
//     private String name;
//
//     @Autowired
//     public Alien(@Value("${alien.id}") int id, @Value("${alien.name}") String name) {
//         this.id = id;
//         this.name = name;
//     }
// }
// In this example, the Alien class has a constructor that takes two parameters: id and name.
// The @Autowired annotation is used to indicate that this constructor should be used for dependency injection.
// The @Value annotation is used to inject the values of alien.id and alien.name from the application properties file into the constructor parameters.
// The Spring container will call this constructor when creating an instance of the Alien bean and pass the required values for id and name.
// This ensures that the dependencies are provided at the time of bean creation and makes the Alien class immutable, as the properties cannot be changed after the object is created.
// Note: In constructor injection, all dependencies are required, meaning that if a required dependency is not provided, the bean cannot be created and will lead to runtime errors.

// When using spring.xml instead of annotations, we can do constructor injection like this:
// <bean id="alien" class="com.example.demo.Alien">
//     <constructor-arg value="1"/>
//     <constructor-arg value="Nielson"/>
// </bean>
// Here, the constructor-arg elements are used to provide the values for the constructor parameters of the Alien class.

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

