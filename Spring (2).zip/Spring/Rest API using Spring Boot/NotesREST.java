public class NotesREST{
    public static void main(String[] args) {
        System.out.println("Hello, World!");
}

// REST API USING SPRING BOOT //

// Note: refoer to Spring MVC Notes too

// We can specify @ResponseBody with controller methods to indicate that the return value should be serialized directly to the HTTP response body.
// This is commonly used in RESTful APIs to return data in formats like JSON or XML. Default response body format in JSON.
// Else, it will look for a view template with the retyurned string as the name of the view to render, which is not what we want in a REST API.
// @RestController is a convenient annotation that combines @Controller and @ResponseBody, eliminating the need to annotate each method with @ResponseBody.

// We need jackson dependency to convert Java objects to JSON and vice versa. Spring Boot includes this dependency by default when you create a web application, so you don't need to add it manually.
// Jackson is automatically configured by Spring Boot, and it will handle the serialization and deserialization of Java objects to and from JSON when you use @RestController or @ResponseBody in your controllers.
// We specify the dependency spring-boot-starter-web in builg.gradle for this.

// We use @PathVariable to extract values from the URI and bind them to method parameters.
// This is useful for creating dynamic endpoints that can handle different inputs based on the URL structure.
// We can also use @RequestParam to extract query parameters from the URL, which is useful for filtering or sorting data in a REST API.

// Example of controller method using @PathVariable and @RequestParam:
/*
@RestController
@RequestMapping("/api/notes")
public class NotesController {
    @GetMapping("/{id}") //url: /api/notes/1 where 1 is id
    public Note getNoteById(@PathVariable("id") Long id) {
        // Logic to retrieve a note by its ID
    }

    @GetMapping //url: /api/notes?title=example
    public List<Note> getNotes(@RequestParam(required = false) String title) {
        // Logic to retrieve notes, optionally filtering by title
    }
 */

// You can have the same endpoint with different HTTP methods to perform different operations in REST.

// Example @PostMapping and @PutMapping:
/*
@RestController
@RequestMapping("/api/notes")
public class NotesController {
    @PostMapping
    public Note createNote(@RequestBody Note note) {
        // Logic to create a new note
    }

    @PutMapping("/{id}")
    public Note updateNote(@PathVariable("id") Long id, @RequestBody Note note) {
        // Logic to update an existing note by its ID
    }
 */

// We need Jackson Dataformat XML dependency to convert Java objects to XML and vice versa. This is not included by default in Spring Boot, so we need to add it manually if we want to support XML in our REST API.

// We can specify the desired response format (JSON or XML) using the produces attribute in the mapping annotations (e.g., @GetMapping, @PostMapping).
// We can also specify the desired request format using the consumes attribute in the mapping annotations when accepting data in the request body (e.g., @PostMapping, @PutMapping).
// Example of specifying response and request formats:
/*
@RestController
@RequestMapping("/api/notes")
public class NotesController {
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = "application/json")
    public Note createNote(@RequestBody Note note) {
        // Logic to create a new note
    }
    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_XML_VALUE)
    public Note getNoteById(@PathVariable("id") Long id) {
        // Logic to retrieve a note by its ID and return it in XML format
    }
    @PostMapping("/notes", consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public Note createNote(@RequestBody Note note) {
        // Logic to create a new note, accepting both JSON and XML formats and returning the created note in the same format as the request
    }
 */

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

